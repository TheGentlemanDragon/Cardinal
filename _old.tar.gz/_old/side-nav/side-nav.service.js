module.exports = SideNavService;

SideNavService.$inject = [];

function SideNavService () {

  return {};

}
