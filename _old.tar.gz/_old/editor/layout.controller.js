module.exports = LayoutController;

LayoutController.$inject = ['$scope', '$state', '$stateParams', '$mdDialog', '$mdToast', 'DataService'];

function LayoutController ($scope, $state, $stateParams, $mdDialog, $mdToast, DataService) {

}
