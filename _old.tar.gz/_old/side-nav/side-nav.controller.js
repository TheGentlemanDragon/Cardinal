module.exports = SideNavController;

SideNavController.$inject = [];

function SideNavController () {
  var vm = this;

  activate()

  function activate() {
  }

}

